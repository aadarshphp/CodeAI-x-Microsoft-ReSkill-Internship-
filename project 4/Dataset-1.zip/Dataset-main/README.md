# YBI Foundation (section 8 not for profit company) 
## We provide opportunity to Learn, Practice and Upskill in emerging technolgies
### Visit us www.ybifoundation.org
